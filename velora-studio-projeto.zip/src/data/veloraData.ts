export const WHATSAPP_NUMBER = '553298353941';
export const WHATSAPP_DISPLAY = '(32) 9835-3941';
export const INSTAGRAM_HANDLE = '@velora.studio_oficial';
export const INSTAGRAM_URL = 'https://www.instagram.com/velora.studio_oficial/';

export const HERO_IMAGE_URL = '/src/assets/images/hero_velora_studio_1794860095432.jpg';
export const ABOUT_IMAGE_URL = '/src/assets/images/about_velora_workspace_1794860096533.jpg';

export function buildWhatsAppUrl(customMessage?: string): string {
  const defaultMessage =
    'Olá, VELORA Studio! Gostaria de solicitar um orçamento para a criação de um site profissional.';
  const text = encodeURIComponent(customMessage || defaultMessage);
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${text}`;
}

export interface DifferentialItem {
  value: string;
  label: string;
  detail: string;
}

export const HERO_DIFFERENTIALS: DifferentialItem[] = [
  {
    value: 'Até 2 dias úteis',
    label: 'Entrega ágil',
    detail: 'Prazos objetivos conforme a complexidade do seu projeto.',
  },
  {
    value: '100% Responsivo',
    label: 'Celular e desktop',
    detail: 'Navegação rápida e legível em qualquer tamanho de tela.',
  },
  {
    value: 'Todo o Brasil',
    label: 'Atendimento online',
    detail: 'Suporte humano e direto pelo WhatsApp, sem burocracia.',
  },
  {
    value: 'Preço acessível',
    label: 'Alto retorno',
    detail: 'Investimento justo pensado para quem quer vender mais.',
  },
];

export type ServiceCategory = 'todos' | 'criacao' | 'crescimento';

export interface ServiceItem {
  number: string;
  title: string;
  category: Exclude<ServiceCategory, 'todos'>;
  categoryLabel: string;
  description: string;
  outcome: string;
}

export const SERVICES: ServiceItem[] = [
  {
    number: '01',
    title: 'Criação de Sites Institucionais',
    category: 'criacao',
    categoryLabel: 'Criação e Design',
    description:
      'Apresente sua empresa com autoridade, clareza e credibilidade para conquistar a confiança de novos clientes logo no primeiro acesso.',
    outcome: 'Ideal para empresas, clínicas e escritórios',
  },
  {
    number: '02',
    title: 'Landing Pages',
    category: 'criacao',
    categoryLabel: 'Criação e Design',
    description:
      'Páginas enxutas e persuasivas focadas em uma única ação: transformar visitantes de anúncios e redes sociais em pedidos no WhatsApp.',
    outcome: 'Foco máximo em conversão e geração de leads',
  },
  {
    number: '03',
    title: 'Sites Comerciais',
    category: 'criacao',
    categoryLabel: 'Criação e Design',
    description:
      'Vitrine digital organizada para destacar seus produtos, serviços, diferenciais e condições comerciais de forma prática para o cliente.',
    outcome: 'Perfeito para comércios locais e prestadores',
  },
  {
    number: '04',
    title: 'Sites Responsivos',
    category: 'criacao',
    categoryLabel: 'Criação e Design',
    description:
      'Layout planejado desde a base para funcionar com fluidez no celular, tablet e computador, respeitando o ritmo de quem navega na rua.',
    outcome: 'Mais de 80% dos acessos vêm do celular',
  },
  {
    number: '05',
    title: 'Design Personalizado',
    category: 'criacao',
    categoryLabel: 'Criação e Design',
    description:
      'Visual exclusivo alinhado às cores, tipografia e posicionamento da sua marca — sem cara de modelo genérico copiado.',
    outcome: 'Identidade visual única e memorável',
  },
  {
    number: '06',
    title: 'Desenvolvimento Web',
    category: 'criacao',
    categoryLabel: 'Criação e Design',
    description:
      'Código limpo, carregamento veloz e arquitetura moderna que garante estabilidade, segurança e excelente experiência de navegação.',
    outcome: 'Desempenho técnico sólido e seguro',
  },
  {
    number: '07',
    title: 'Otimização para SEO',
    category: 'crescimento',
    categoryLabel: 'Otimização e Suporte',
    description:
      'Estrutura semântica, títulos bem hierarquizados e velocidade otimizada para facilitar que sua empresa seja encontrada no Google.',
    outcome: 'Mais visibilidade orgânica para seu negócio',
  },
  {
    number: '08',
    title: 'Integração com WhatsApp',
    category: 'crescimento',
    categoryLabel: 'Otimização e Suporte',
    description:
      'Botões estratégicos e mensagens pré-preenchidas que encurtam o caminho entre o interesse do visitante e a conversa com você.',
    outcome: 'Atendimento imediato em um único toque',
  },
  {
    number: '09',
    title: 'Integração com Redes Sociais',
    category: 'crescimento',
    categoryLabel: 'Otimização e Suporte',
    description:
      'Conexão direta entre seu site, Instagram e demais canais da marca, fortalecendo sua presença digital de ponta a ponta.',
    outcome: 'Ecossistema digital unificado e coerente',
  },
  {
    number: '10',
    title: 'Modernização de Sites',
    category: 'crescimento',
    categoryLabel: 'Otimização e Suporte',
    description:
      'Renovamos sites antigos, lentos ou desalinhados no celular para uma experiência atual, limpa e preparada para gerar negócios hoje.',
    outcome: 'Nova imagem profissional sem perder sua história',
  },
  {
    number: '11',
    title: 'Manutenção de Sites',
    category: 'crescimento',
    categoryLabel: 'Otimização e Suporte',
    description:
      'Atualizações de conteúdo, ajustes visuais e acompanhamento contínuo para que seu site permaneça sempre no ar, rápido e atualizado.',
    outcome: 'Tranquilidade para focar no seu negócio',
  },
];

export type ProjectCategory =
  | 'Todos'
  | 'Sites Institucionais'
  | 'Landing Pages'
  | 'Comércio Local';

export interface ProjectItem {
  id: string;
  title: string;
  client: string;
  category: Exclude<ProjectCategory, 'Todos'>;
  segment: string;
  location: string;
  image: string;
  metric: string;
  summary: string;
  challenge: string;
  solution: string;
  deliverables: string[];
  turnaround: string;
}

export const PORTFOLIO_PROJECTS: ProjectItem[] = [
  {
    id: 'clinica-bem-estar',
    title: 'Clínica Bem-Estar Integrada',
    client: 'Clínica Bem-Estar',
    category: 'Sites Institucionais',
    segment: 'Saúde e Atendimento Clínico',
    location: 'Belo Horizonte · MG',
    image: '/src/assets/images/portfolio_saude_clinica_1794860096198.jpg',
    metric: '+165% agendamentos via WhatsApp em 60 dias',
    summary:
      'Site institucional acolhedor com apresentação de especialidades, corpo clínico e agendamento direto pelo WhatsApp.',
    challenge:
      'A clínica dependia apenas de indicações e redes sociais, sem um endereço digital que transmitisse confiança para novos pacientes.',
    solution:
      'Criamos uma arquitetura clara com foco em legibilidade mobile, prova social de pacientes e botões diretos por especialidade.',
    deliverables: [
      'Site Institucional Responsivo',
      'Design Personalizado',
      'Integração com WhatsApp',
      'Otimização para SEO Local',
    ],
    turnaround: '2 dias úteis',
  },
  {
    id: 'studio-norte-arquitetura',
    title: 'Studio Norte Arquitetura',
    client: 'Studio Norte',
    category: 'Sites Institucionais',
    segment: 'Arquitetura e Interiores',
    location: 'Curitiba · PR',
    image: '/src/assets/images/portfolio_arquitetura_site_1794860098131.jpg',
    metric: '3,4x mais solicitações de orçamento no trimestre',
    summary:
      'Portfólio minimalista com galeria de projetos residenciais e comerciais desenhado para valorizar cada detalhe visual.',
    challenge:
      'O escritório possuía um site antigo e pesado que demorava para carregar fotos no celular e dificultava o primeiro contato.',
    solution:
      'Modernizamos toda a estrutura com estética editorial, carregamento otimizado de imagens e fluxo de orçamento simplificado.',
    deliverables: [
      'Modernização de Site',
      'Galeria de Projetos',
      'Integração com Instagram',
      'Performance Mobile-First',
    ],
    turnaround: '2 dias úteis',
  },
  {
    id: 'torrefacao-raiz',
    title: 'Torrefação & Padaria Raiz',
    client: 'Torrefação Raiz',
    category: 'Comércio Local',
    segment: 'Gastronomia e Comércio Local',
    location: 'Juiz de Fora · MG',
    image: '/src/assets/images/portfolio_comercio_local_1794860098128.jpg',
    metric: 'Carregamento em 0,8s no 4G e +90 pedidos semanais',
    summary:
      'Site comercial com cardápio digital, história da marca e pedido rápido para retiradas e encomendas via WhatsApp.',
    challenge:
      'Clientes do bairro buscavam horários, cardápio e encomendas no Google, mas não encontravam informações atualizadas.',
    solution:
      'Desenvolvemos um site comercial direto ao ponto, integrado ao Google e ao WhatsApp da loja para agilizar os pedidos diários.',
    deliverables: [
      'Site Comercial',
      'Cardápio Digital Responsivo',
      'Integração WhatsApp e Redes',
      'SEO para Busca Local',
    ],
    turnaround: '2 dias úteis',
  },
  {
    id: 'vertice-consultoria',
    title: 'Vértice Consultoria Empresarial',
    client: 'Vértice Gestão',
    category: 'Landing Pages',
    segment: 'Serviços Corporativos B2B',
    location: 'São Paulo · SP',
    image: '/src/assets/images/portfolio_servicos_landing_1794860098143.jpg',
    metric: '11,4% de taxa de conversão em tráfego pago',
    summary:
      'Landing page objetiva para captação de empresários interessados em consultoria financeira e reestruturação.',
    challenge:
      'Os anúncios direcionavam para uma página genérica sem hierarquia de argumentos, desperdiçando parte do investimento em mídia.',
    solution:
      'Estruturamos uma narrativa persuasiva passo a passo, com benefícios claros, depoimentos e chamada imediata para conversa no WhatsApp.',
    deliverables: [
      'Landing Page de Conversão',
      'Copywriting Estratégico',
      'Desenvolvimento Web Ágil',
      'Integração com WhatsApp',
    ],
    turnaround: '2 dias úteis',
  },
];

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  company: string;
  city: string;
  quote: string;
  result: string;
}

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 'camila-rezende',
    name: 'Camila Rezende',
    role: 'Sócia-diretora',
    company: 'Clínica Bem-Estar Integrada',
    city: 'Belo Horizonte · MG',
    quote:
      'Antes tínhamos apenas o Instagram e perdíamos pacientes que pesquisavam no Google. Em dois dias úteis a VELORA Studio colocou nosso site no ar com um atendimento muito próximo, e já na primeira semana dobramos os agendamentos pelo WhatsApp.',
    result: 'Site entregue em 2 dias úteis e agenda mais previsível',
  },
  {
    id: 'henrique-vasconcelos',
    name: 'Henrique Vasconcelos',
    role: 'Arquiteto Titular',
    company: 'Studio Norte Arquitetura',
    city: 'Curitiba · PR',
    quote:
      'Nosso site antigo travava no celular e não passava o nível do nosso trabalho. A modernização deixou tudo limpo, rápido e elegante. Hoje os clientes chegam à reunião pelo WhatsApp já encantados com o portfólio.',
    result: '3,4x mais pedidos de orçamento qualificados',
  },
  {
    id: 'marcos-vinicius',
    name: 'Marcos Vinícius Prado',
    role: 'Proprietário',
    company: 'Torrefação & Padaria Raiz',
    city: 'Juiz de Fora · MG',
    quote:
      'Achei que ter um site profissional custaria caro e levaria semanas. Foi tudo direto ao ponto, com preço justo para um comércio local e comunicação humana do início ao fim. Agora nossos clientes encomendam direto pelo WhatsApp.',
    result: 'Presença profissional no Google com retorno rápido',
  },
];
