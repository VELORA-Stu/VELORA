import { Quote } from 'lucide-react';
import { motion } from 'motion/react';
import { TESTIMONIALS } from '../data/veloraData';

export function TestimonialsSection() {
  return (
    <section id="depoimentos" className="bg-white py-16 sm:py-20 lg:py-24">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl pb-8 border-b border-[#E3DDD1]">
          <p className="text-sm font-medium text-[#1B4D3E]">
            Depoimentos de clientes
          </p>
          <h2 className="mt-2 font-display text-3xl sm:text-4xl font-semibold tracking-tight text-[#16231C] text-balance">
            Quem investiu em um site profissional sente a diferença no dia a dia.
          </h2>
        </div>

        <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((item, index) => (
            <motion.blockquote
              key={item.id}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.15 }}
              transition={{
                duration: 0.4,
                delay: index * 0.06,
                ease: [0.16, 1, 0.3, 1],
              }}
              className="p-6 sm:p-7 rounded-2xl border border-[#E3DDD1] bg-[#FAF8F4] flex flex-col justify-between"
            >
              <div>
                <Quote
                  className="w-6 h-6 text-[#1B4D3E]/70 mb-4"
                  aria-hidden="true"
                />
                <p className="text-sm sm:text-base leading-relaxed text-[#16231C]">
                  “{item.quote}”
                </p>
              </div>

              <footer className="mt-6 pt-5 border-t border-[#E3DDD1]">
                <p className="text-xs font-semibold text-[#1B4D3E] mb-2">
                  {item.result}
                </p>
                <p className="font-display text-base font-semibold text-[#16231C]">
                  {item.name}
                </p>
                <p className="text-xs text-[#4A5850] mt-0.5">
                  {item.role} · {item.company}
                </p>
                <p className="text-xs text-[#4A5850]">{item.city}</p>
              </footer>
            </motion.blockquote>
          ))}
        </div>
      </div>
    </section>
  );
}
