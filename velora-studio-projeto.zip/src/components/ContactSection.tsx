import { useState, type FormEvent } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Instagram,
  MapPin,
  MessageCircle,
  Phone,
} from 'lucide-react';
import { motion } from 'motion/react';
import {
  INSTAGRAM_HANDLE,
  INSTAGRAM_URL,
  WHATSAPP_DISPLAY,
  buildWhatsAppUrl,
} from '../data/veloraData';

interface FormState {
  nome: string;
  empresa: string;
  telefone: string;
  tipoProjeto: string;
  mensagem: string;
}

interface FormErrors {
  nome?: string;
  telefone?: string;
  mensagem?: string;
}

const PROJECT_TYPES = [
  'Site Institucional',
  'Landing Page',
  'Site Comercial',
  'Modernização de Site',
  'Manutenção / SEO / Integrações',
];

export function ContactSection() {
  const [form, setForm] = useState<FormState>({
    nome: '',
    empresa: '',
    telefone: '',
    tipoProjeto: 'Site Institucional',
    mensagem: '',
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [submittedUrl, setSubmittedUrl] = useState<string | null>(null);

  const directWhatsAppHref = buildWhatsAppUrl(
    'Olá, VELORA Studio! Quero solicitar um orçamento para criar o site do meu negócio.'
  );

  function validate(): FormErrors {
    const nextErrors: FormErrors = {};
    if (!form.nome.trim() || form.nome.trim().length < 2) {
      nextErrors.nome = 'Informe seu nome para podermos atender você.';
    }
    const digits = form.telefone.replace(/\D/g, '');
    if (digits.length < 10) {
      nextErrors.telefone =
        'Informe um WhatsApp ou telefone válido com DDD (ex.: 32 9835-3941).';
    }
    if (!form.mensagem.trim() || form.mensagem.trim().length < 8) {
      nextErrors.mensagem =
        'Conte brevemente sobre sua empresa ou o que precisa no site.';
    }
    return nextErrors;
  }

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setErrors({});
    const summaryLines = [
      `Olá, VELORA Studio! Gostaria de solicitar um orçamento pelo WhatsApp.`,
      ``,
      `Nome: ${form.nome.trim()}`,
      form.empresa.trim() ? `Empresa / Segmento: ${form.empresa.trim()}` : '',
      `WhatsApp para retorno: ${form.telefone.trim()}`,
      `Tipo de projeto: ${form.tipoProjeto}`,
      `Objetivo: ${form.mensagem.trim()}`,
    ]
      .filter(Boolean)
      .join('\n');

    setSubmittedUrl(buildWhatsAppUrl(summaryLines));
  }

  function handleReset() {
    setSubmittedUrl(null);
    setForm({
      nome: '',
      empresa: '',
      telefone: '',
      tipoProjeto: 'Site Institucional',
      mensagem: '',
    });
    setErrors({});
  }

  return (
    <section
      id="contato"
      className="bg-[#F7F4ED] border-t border-[#E3DDD1] py-16 sm:py-20 lg:py-24"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
          {/* Left column: Persuasive direct contact details */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5"
          >
            <p className="text-sm font-medium text-[#1B4D3E]">
              Vamos tirar seu projeto do papel
            </p>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl font-semibold tracking-tight text-[#16231C] text-balance">
              Solicite seu orçamento sem compromisso.
            </h2>
            <p className="mt-4 text-base leading-relaxed text-[#4A5850]">
              Atendimento direto e humanizado para empresas, profissionais
              autônomos e comércios locais. Entregamos projetos em até 2 dias
              úteis conforme a complexidade.
            </p>

            <div className="mt-8">
              <a
                href={directWhatsAppHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 min-h-[48px] rounded-xl bg-[#1B4D3E] hover:bg-[#143A2E] text-white text-base font-medium transition-colors duration-150 whitespace-nowrap"
              >
                <MessageCircle className="w-5 h-5 shrink-0" aria-hidden="true" />
                <span>Solicitar orçamento pelo WhatsApp</span>
              </a>
            </div>

            <div className="mt-10 pt-8 border-t border-[#DED7C8] space-y-4">
              <div className="flex items-start gap-3">
                <Phone
                  className="w-5 h-5 text-[#1B4D3E] shrink-0 mt-0.5"
                  aria-hidden="true"
                />
                <div>
                  <p className="text-xs font-medium text-[#4A5850]">WhatsApp</p>
                  <a
                    href={directWhatsAppHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-base font-semibold text-[#16231C] hover:text-[#1B4D3E] transition-colors tabular-nums"
                  >
                    {WHATSAPP_DISPLAY}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Instagram
                  className="w-5 h-5 text-[#1B4D3E] shrink-0 mt-0.5"
                  aria-hidden="true"
                />
                <div>
                  <p className="text-xs font-medium text-[#4A5850]">Instagram</p>
                  <a
                    href={INSTAGRAM_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-base font-semibold text-[#16231C] hover:text-[#1B4D3E] transition-colors"
                  >
                    {INSTAGRAM_HANDLE}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <MapPin
                  className="w-5 h-5 text-[#1B4D3E] shrink-0 mt-0.5"
                  aria-hidden="true"
                />
                <div>
                  <p className="text-xs font-medium text-[#4A5850]">
                    Área de atendimento
                  </p>
                  <p className="text-base font-medium text-[#16231C]">
                    Atendimento online para todo o Brasil
                  </p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right column: Validated Briefing Form -> WhatsApp */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{ duration: 0.4, delay: 0.06, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 bg-white rounded-2xl border border-[#E3DDD1] p-6 sm:p-8 lg:p-10"
          >
            {submittedUrl ? (
              <div className="py-6 space-y-5">
                <div className="w-12 h-12 rounded-xl bg-[#E6EFEA] text-[#1B4D3E] flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6" aria-hidden="true" />
                </div>
                <div>
                  <h3 className="font-display text-2xl font-semibold text-[#16231C]">
                    Briefing pronto para envio!
                  </h3>
                  <p className="mt-2 text-base text-[#4A5850] leading-relaxed">
                    Organizamos suas informações para agilizar seu atendimento.
                    Clique no botão abaixo para enviar os dados diretamente para
                    o WhatsApp da VELORA Studio.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
                  <a
                    href={submittedUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 px-6 py-3.5 min-h-[48px] rounded-xl bg-[#1B4D3E] hover:bg-[#143A2E] text-white text-sm font-medium transition-colors"
                  >
                    <MessageCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
                    <span>Solicitar orçamento pelo WhatsApp</span>
                  </a>
                  <button
                    type="button"
                    onClick={handleReset}
                    className="px-4 py-3 min-h-[44px] rounded-xl border border-[#E3DDD1] text-sm font-medium text-[#16231C] hover:bg-[#F7F4ED] transition-colors"
                  >
                    Editar informações
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate className="space-y-5">
                <div>
                  <h3 className="font-display text-xl font-semibold text-[#16231C]">
                    Conte brevemente sobre o seu projeto
                  </h3>
                  <p className="mt-1 text-sm text-[#4A5850]">
                    Preencha os campos abaixo e gere seu pedido de orçamento
                    pronto para o WhatsApp.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label
                      htmlFor="contato-nome"
                      className="block text-sm font-medium text-[#16231C] mb-1.5"
                    >
                      Seu nome *
                    </label>
                    <input
                      id="contato-nome"
                      name="nome"
                      type="text"
                      autoComplete="name"
                      value={form.nome}
                      onChange={(e) => {
                        setForm((prev) => ({ ...prev, nome: e.target.value }));
                        if (errors.nome)
                          setErrors((prev) => ({ ...prev, nome: undefined }));
                      }}
                      placeholder="Ex.: Mariana Alves"
                      aria-invalid={Boolean(errors.nome)}
                      className="w-full px-3.5 py-2.5 min-h-[44px] rounded-xl border border-[#D8D1C4] bg-white text-sm text-[#16231C] placeholder:text-[#7A857E] focus:border-[#1B4D3E] focus:outline-none"
                    />
                    {errors.nome && (
                      <p className="mt-1.5 flex items-center gap-1.5 text-xs font-medium text-[#991B1B]">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                        <span>{errors.nome}</span>
                      </p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="contato-empresa"
                      className="block text-sm font-medium text-[#16231C] mb-1.5"
                    >
                      Empresa ou segmento
                    </label>
                    <input
                      id="contato-empresa"
                      name="empresa"
                      type="text"
                      value={form.empresa}
                      onChange={(e) =>
                        setForm((prev) => ({ ...prev, empresa: e.target.value }))
                      }
                      placeholder="Ex.: Clínica Odontológica / Autônomo"
                      className="w-full px-3.5 py-2.5 min-h-[44px] rounded-xl border border-[#D8D1C4] bg-white text-sm text-[#16231C] placeholder:text-[#7A857E] focus:border-[#1B4D3E] focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label
                      htmlFor="contato-telefone"
                      className="block text-sm font-medium text-[#16231C] mb-1.5"
                    >
                      Seu WhatsApp *
                    </label>
                    <input
                      id="contato-telefone"
                      name="telefone"
                      type="tel"
                      autoComplete="tel"
                      value={form.telefone}
                      onChange={(e) => {
                        setForm((prev) => ({
                          ...prev,
                          telefone: e.target.value,
                        }));
                        if (errors.telefone)
                          setErrors((prev) => ({
                            ...prev,
                            telefone: undefined,
                          }));
                      }}
                      placeholder="(32) 99999-9999"
                      aria-invalid={Boolean(errors.telefone)}
                      className="w-full px-3.5 py-2.5 min-h-[44px] rounded-xl border border-[#D8D1C4] bg-white text-sm text-[#16231C] placeholder:text-[#7A857E] focus:border-[#1B4D3E] focus:outline-none"
                    />
                    {errors.telefone && (
                      <p className="mt-1.5 flex items-center gap-1.5 text-xs font-medium text-[#991B1B]">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                        <span>{errors.telefone}</span>
                      </p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="contato-tipo"
                      className="block text-sm font-medium text-[#16231C] mb-1.5"
                    >
                      O que você precisa?
                    </label>
                    <select
                      id="contato-tipo"
                      name="tipoProjeto"
                      value={form.tipoProjeto}
                      onChange={(e) =>
                        setForm((prev) => ({
                          ...prev,
                          tipoProjeto: e.target.value,
                        }))
                      }
                      className="w-full px-3.5 py-2.5 min-h-[44px] rounded-xl border border-[#D8D1C4] bg-white text-sm text-[#16231C] focus:border-[#1B4D3E] focus:outline-none"
                    >
                      {PROJECT_TYPES.map((type) => (
                        <option key={type} value={type}>
                          {type}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="contato-mensagem"
                    className="block text-sm font-medium text-[#16231C] mb-1.5"
                  >
                    Descreva seu objetivo *
                  </label>
                  <textarea
                    id="contato-mensagem"
                    name="mensagem"
                    rows={4}
                    value={form.mensagem}
                    onChange={(e) => {
                      setForm((prev) => ({ ...prev, mensagem: e.target.value }));
                      if (errors.mensagem)
                        setErrors((prev) => ({ ...prev, mensagem: undefined }));
                    }}
                    placeholder="Ex.: Quero um site profissional para apresentar meus serviços e receber pedidos pelo WhatsApp."
                    aria-invalid={Boolean(errors.mensagem)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#D8D1C4] bg-white text-sm text-[#16231C] placeholder:text-[#7A857E] focus:border-[#1B4D3E] focus:outline-none resize-y"
                  />
                  {errors.mensagem && (
                    <p className="mt-1.5 flex items-center gap-1.5 text-xs font-medium text-[#991B1B]">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                      <span>{errors.mensagem}</span>
                    </p>
                  )}
                </div>

                <div className="pt-1 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <button
                    type="submit"
                    className="inline-flex items-center justify-center gap-2 px-6 py-3.5 min-h-[48px] rounded-xl bg-[#1B4D3E] hover:bg-[#143A2E] text-white text-sm font-medium transition-colors duration-150 whitespace-nowrap"
                  >
                    <MessageCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
                    <span>Solicitar orçamento pelo WhatsApp</span>
                  </button>
                  <span className="text-xs text-[#4A5850]">
                    Resposta rápida durante horário comercial.
                  </span>
                </div>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
