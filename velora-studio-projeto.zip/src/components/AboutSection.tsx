import { MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { ABOUT_IMAGE_URL, buildWhatsAppUrl } from '../data/veloraData';
import { ResilientImage } from './ResilientImage';

const STUDIO_PILLARS = [
  {
    title: 'Entrega em até 2 dias úteis',
    description:
      'Processo enxuto e organizado para colocar sua empresa no ar com agilidade, conforme a complexidade do projeto.',
  },
  {
    title: 'Atendimento humanizado e direto',
    description:
      'Você conversa diretamente com quem projeta seu site pelo WhatsApp, sem robôs nem termos complicados.',
  },
  {
    title: 'Preços acessíveis e transparentes',
    description:
      'Condições pensadas para pequenas e médias empresas, autônomos, prestadores de serviços e comércios locais.',
  },
  {
    title: 'Presença digital estratégica',
    description:
      'Design personalizado, responsivo para celulares e computadores, pensado para gerar contatos reais.',
  },
];

export function AboutSection() {
  const whatsappHref = buildWhatsAppUrl(
    'Olá, VELORA Studio! Gostaria de conversar sobre um site para o meu negócio.'
  );

  return (
    <section
      id="sobre"
      className="bg-[#F7F4ED] border-y border-[#E3DDD1] py-16 sm:py-20 lg:py-24"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-stretch">
          {/* Studio visual */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 flex"
          >
            <div className="w-full rounded-2xl overflow-hidden border border-[#E3DDD1] bg-[#EFEAE0] aspect-[4/3] lg:aspect-auto">
              <ResilientImage
                src={ABOUT_IMAGE_URL}
                alt="Ambiente minimalista da VELORA Studio com luz natural, mesa de carvalho e folhagens verdes"
                titleFallback="VELORA Studio — Atendimento Online"
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>

          {/* Editorial narrative */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{ duration: 0.45, delay: 0.06, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 flex flex-col justify-center"
          >
            <p className="text-sm font-medium text-[#1B4D3E]">
              Sobre a VELORA Studio
            </p>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl font-semibold tracking-tight text-[#16231C] text-balance">
              Todo negócio merece ter seu espaço no mundo digital.
            </h2>

            <div className="mt-5 space-y-4 text-base leading-relaxed text-[#4A5850]">
              <p>
                A <strong className="font-semibold text-[#16231C]">VELORA Studio</strong> é uma
                agência digital especializada na criação de sites profissionais para
                empresas, empreendedores e negócios de todos os segmentos. Nosso
                propósito é transformar ideias em experiências digitais modernas,
                funcionais e estratégicas, ajudando marcas a fortalecerem sua
                presença online, conquistarem credibilidade e ampliarem suas
                oportunidades de negócio.
              </p>
              <p>
                Trabalhamos com foco em design, tecnologia, responsividade e
                soluções personalizadas, desenvolvendo projetos que valorizam a
                identidade de cada empresa e conectam negócios aos seus clientes —
                com atendimento online para todo o Brasil.
              </p>
            </div>

            {/* Clean hairline-separated pillars (no nested card clutter) */}
            <div className="mt-8 pt-8 border-t border-[#DED7C8] grid grid-cols-1 sm:grid-cols-2 gap-6">
              {STUDIO_PILLARS.map((pillar) => (
                <div key={pillar.title}>
                  <h3 className="font-display text-base font-semibold text-[#16231C]">
                    {pillar.title}
                  </h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-[#4A5850]">
                    {pillar.description}
                  </p>
                </div>
              ))}
            </div>

            <div className="mt-8">
              <a
                href={whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-5 py-3 min-h-[44px] rounded-xl bg-[#1B4D3E] hover:bg-[#143A2E] text-white text-sm font-medium transition-colors duration-150 whitespace-nowrap"
              >
                <MessageCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>Solicitar orçamento pelo WhatsApp</span>
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
