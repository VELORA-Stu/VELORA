import { useState } from 'react';
import { ArrowUpRight, MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';
import {
  SERVICES,
  type ServiceCategory,
  buildWhatsAppUrl,
} from '../data/veloraData';

const SERVICE_FILTERS: { id: ServiceCategory; label: string }[] = [
  { id: 'todos', label: 'Todos os serviços' },
  { id: 'criacao', label: 'Criação e Design' },
  { id: 'crescimento', label: 'SEO, WhatsApp e Suporte' },
];

export function ServicesSection() {
  const [activeCategory, setActiveCategory] = useState<ServiceCategory>('todos');

  const filteredServices =
    activeCategory === 'todos'
      ? SERVICES
      : SERVICES.filter((service) => service.category === activeCategory);

  const mainWhatsappHref = buildWhatsAppUrl(
    'Olá, VELORA Studio! Vi os serviços no site e gostaria de solicitar um orçamento pelo WhatsApp.'
  );

  return (
    <section id="servicos" className="bg-white py-16 sm:py-20 lg:py-24">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header + Interactive Filter Controls */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-8 border-b border-[#E3DDD1]">
          <div className="max-w-2xl">
            <p className="text-sm font-medium text-[#1B4D3E]">
              Soluções sob medida
            </p>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl font-semibold tracking-tight text-[#16231C] text-balance">
              Tudo o que seu negócio precisa para se destacar na internet.
            </h2>
            <p className="mt-3 text-base text-[#4A5850] leading-relaxed">
              Do primeiro site institucional à modernização completa e integração
              direta com seu WhatsApp e redes sociais.
            </p>
          </div>

          <div
            role="tablist"
            aria-label="Filtrar serviços por categoria"
            className="inline-flex flex-wrap items-center gap-1 p-1 bg-[#F7F4ED] border border-[#E3DDD1] rounded-xl self-start lg:self-auto"
          >
            {SERVICE_FILTERS.map((filter) => {
              const isActive = activeCategory === filter.id;
              return (
                <button
                  key={filter.id}
                  type="button"
                  role="tab"
                  aria-selected={isActive}
                  onClick={() => setActiveCategory(filter.id)}
                  className={`px-3.5 py-2 min-h-[40px] rounded-lg text-sm font-medium transition-colors duration-150 whitespace-nowrap shrink-0 ${
                    isActive
                      ? 'bg-[#1B4D3E] text-white'
                      : 'text-[#4A5850] hover:text-[#16231C] hover:bg-white/70'
                  }`}
                >
                  {filter.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Services Editorial Grid */}
        <div className="mt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredServices.map((service, index) => {
            const serviceWhatsApp = buildWhatsAppUrl(
              `Olá, VELORA Studio! Tenho interesse em "${service.title}" e gostaria de solicitar um orçamento.`
            );

            return (
              <motion.article
                key={service.number}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.1 }}
                transition={{
                  duration: 0.35,
                  delay: Math.min(index * 0.03, 0.2),
                  ease: [0.16, 1, 0.3, 1],
                }}
                className="flex flex-col justify-between p-6 rounded-2xl border border-[#E3DDD1] bg-[#FAF8F4] hover:border-[#1B4D3E]/50 transition-colors duration-150"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 text-xs text-[#4A5850] mb-3">
                    <span className="font-medium text-[#1B4D3E] tabular-nums">
                      {service.number}. {service.categoryLabel}
                    </span>
                  </div>

                  <h3 className="font-display text-xl font-semibold text-[#16231C]">
                    {service.title}
                  </h3>

                  <p className="mt-2.5 text-sm leading-relaxed text-[#4A5850]">
                    {service.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-[#E3DDD1] flex items-center justify-between gap-3">
                  <span className="text-xs text-[#4A5850] truncate">
                    {service.outcome}
                  </span>
                  <a
                    href={serviceWhatsApp}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-sm font-medium text-[#1B4D3E] hover:text-[#143A2E] whitespace-nowrap shrink-0 py-1"
                  >
                    <span>Orçar</span>
                    <ArrowUpRight className="w-4 h-4" aria-hidden="true" />
                  </a>
                </div>
              </motion.article>
            );
          })}
        </div>

        {/* Bottom Conversion Strip */}
        <div className="mt-12 p-6 sm:p-8 rounded-2xl bg-[#F7F4ED] border border-[#E3DDD1] flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div>
            <h3 className="font-display text-xl font-semibold text-[#16231C]">
              Não sabe exatamente qual formato é ideal para sua empresa?
            </h3>
            <p className="mt-1 text-sm sm:text-base text-[#4A5850]">
              Fale direto no WhatsApp e indicamos a solução certa para o seu
              momento e orçamento.
            </p>
          </div>
          <a
            href={mainWhatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-6 py-3.5 min-h-[48px] rounded-xl bg-[#1B4D3E] hover:bg-[#143A2E] text-white text-sm font-medium transition-colors duration-150 whitespace-nowrap shrink-0"
          >
            <MessageCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>Solicitar orçamento pelo WhatsApp</span>
          </a>
        </div>
      </div>
    </section>
  );
}
