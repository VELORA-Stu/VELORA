import { ArrowRight, MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';
import {
  HERO_DIFFERENTIALS,
  HERO_IMAGE_URL,
  buildWhatsAppUrl,
} from '../data/veloraData';
import { ResilientImage } from './ResilientImage';

export function HeroSection() {
  const whatsappHref = buildWhatsAppUrl(
    'Olá, VELORA Studio! Quero colocar minha empresa no digital e solicitar um orçamento.'
  );

  return (
    <section id="inicio" className="bg-white pt-10 pb-14 sm:pt-14 sm:pb-20 lg:pt-20 lg:pb-24">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Split-screen hero with matching column height */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
          {/* Left column: Typographic hierarchy & primary WhatsApp CTA */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 flex flex-col justify-center"
          >
            <p className="text-sm font-medium text-[#4A5850] mb-4">
              <span>Criação de Sites Profissionais</span>
              <span className="mx-2 text-[#B8B0A0]" aria-hidden="true">
                ·
              </span>
              <span>Atendimento online para todo o Brasil</span>
            </p>

            <h1 className="font-display text-[2.25rem] sm:text-[3rem] lg:text-[3.5rem] font-semibold leading-[1.08] tracking-tight text-[#16231C] text-balance">
              Sua empresa no digital. Seu negócio em outro nível.
            </h1>

            <p className="mt-5 text-base sm:text-lg leading-relaxed text-[#4A5850] max-w-xl">
              Criamos sites modernos, rápidos e personalizados para empresas,
              empreendedores, profissionais autônomos e comércios locais que
              querem transmitir credibilidade e conquistar mais clientes todos os
              dias.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row sm:items-center gap-4">
              <a
                href={whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 min-h-[48px] rounded-xl bg-[#1B4D3E] hover:bg-[#143A2E] text-white text-base font-medium transition-colors duration-150 whitespace-nowrap shrink-0"
              >
                <MessageCircle className="w-5 h-5 shrink-0" aria-hidden="true" />
                <span>Solicitar orçamento pelo WhatsApp</span>
              </a>

              <a
                href="#portfolio"
                className="inline-flex items-center justify-center gap-2 px-4 py-3 min-h-[44px] text-sm font-medium text-[#16231C] hover:text-[#1B4D3E] transition-colors duration-150 whitespace-nowrap shrink-0"
              >
                <span>Ver projetos realizados</span>
                <ArrowRight className="w-4 h-4 shrink-0" aria-hidden="true" />
              </a>
            </div>
          </motion.div>

          {/* Right column: Full-height visual anchor */}
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 flex"
          >
            <div className="w-full rounded-2xl overflow-hidden border border-[#E3DDD1] bg-[#F7F4ED] aspect-[16/10] lg:aspect-auto lg:min-h-[420px]">
              <ResilientImage
                src={HERO_IMAGE_URL}
                alt="Mesa minimalista do estúdio VELORA com notebook exibindo um site profissional em tons claros e verdes"
                titleFallback="VELORA Studio — Design Digital"
                priority
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>
        </div>

        {/* Full-width 4-column differential strip below the split */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.16, ease: [0.16, 1, 0.3, 1] }}
          className="mt-12 lg:mt-16 pt-8 border-t border-[#E3DDD1] grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8"
        >
          {HERO_DIFFERENTIALS.map((item) => (
            <div key={item.value} className="flex flex-col">
              <span className="font-display text-lg sm:text-xl font-semibold text-[#1B4D3E] tabular-nums">
                {item.value}
              </span>
              <span className="mt-1 text-sm font-medium text-[#16231C]">
                {item.label}
              </span>
              <p className="mt-1 text-sm text-[#4A5850] leading-relaxed">
                {item.detail}
              </p>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
