import { useEffect, useState } from 'react';
import { ArrowUpRight, Check, MessageCircle, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import {
  PORTFOLIO_PROJECTS,
  type ProjectCategory,
  type ProjectItem,
  buildWhatsAppUrl,
} from '../data/veloraData';
import { ResilientImage } from './ResilientImage';

const PROJECT_FILTERS: ProjectCategory[] = [
  'Todos',
  'Sites Institucionais',
  'Landing Pages',
  'Comércio Local',
];

export function PortfolioSection() {
  const [selectedCategory, setSelectedCategory] =
    useState<ProjectCategory>('Todos');
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(
    null
  );

  const filteredProjects =
    selectedCategory === 'Todos'
      ? PORTFOLIO_PROJECTS
      : PORTFOLIO_PROJECTS.filter((p) => p.category === selectedCategory);

  useEffect(() => {
    if (!selectedProject) return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setSelectedProject(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedProject]);

  return (
    <section
      id="portfolio"
      className="bg-[#F7F4ED] border-y border-[#E3DDD1] py-16 sm:py-20 lg:py-24"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header + Category Filters */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-8 border-b border-[#DED7C8]">
          <div className="max-w-2xl">
            <p className="text-sm font-medium text-[#1B4D3E]">
              Portfólio e projetos
            </p>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl font-semibold tracking-tight text-[#16231C] text-balance">
              Sites pensados para gerar confiança e pedidos reais.
            </h2>
            <p className="mt-3 text-base text-[#4A5850] leading-relaxed">
              Projetos desenvolvidos para diferentes segmentos, sempre com
              visual limpo, carregamento rápido e conversão integrada ao WhatsApp.
            </p>
          </div>

          <div
            role="tablist"
            aria-label="Filtrar projetos por tipo"
            className="inline-flex flex-wrap items-center gap-1 p-1 bg-white border border-[#E3DDD1] rounded-xl self-start lg:self-auto"
          >
            {PROJECT_FILTERS.map((category) => {
              const isActive = selectedCategory === category;
              return (
                <button
                  key={category}
                  type="button"
                  role="tab"
                  aria-selected={isActive}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-3.5 py-2 min-h-[40px] rounded-lg text-sm font-medium transition-colors duration-150 whitespace-nowrap shrink-0 ${
                    isActive
                      ? 'bg-[#1B4D3E] text-white'
                      : 'text-[#4A5850] hover:text-[#16231C] hover:bg-[#F7F4ED]'
                  }`}
                >
                  {category}
                </button>
              );
            })}
          </div>
        </div>

        {/* 2-Column Editorial Case Grid */}
        <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredProjects.map((project, index) => (
            <motion.article
              key={project.id}
              initial={{ opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.12 }}
              transition={{
                duration: 0.4,
                delay: index * 0.05,
                ease: [0.16, 1, 0.3, 1],
              }}
              className="group bg-white rounded-2xl border border-[#E3DDD1] overflow-hidden flex flex-col"
            >
              <button
                type="button"
                onClick={() => setSelectedProject(project)}
                className="text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-[#1B4D3E] flex flex-col flex-1"
              >
                <div className="w-full aspect-[4/3] overflow-hidden bg-[#EFEAE0] border-b border-[#E3DDD1]">
                  <ResilientImage
                    src={project.image}
                    alt={`Mockup do site desenvolvido para ${project.title}`}
                    titleFallback={project.title}
                    className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300 ease-out"
                  />
                </div>

                <div className="p-6 flex flex-col flex-1 justify-between">
                  <div>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-[#4A5850]">
                      <span className="font-medium text-[#1B4D3E]">
                        {project.category}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{project.segment}</span>
                      <span aria-hidden="true">·</span>
                      <span>{project.location}</span>
                    </div>

                    <h3 className="mt-2 font-display text-xl sm:text-2xl font-semibold text-[#16231C] group-hover:text-[#1B4D3E] transition-colors">
                      {project.title}
                    </h3>

                    <p className="mt-2 text-sm leading-relaxed text-[#4A5850]">
                      {project.summary}
                    </p>
                  </div>

                  <div className="mt-6 pt-4 border-t border-[#E3DDD1] flex items-center justify-between gap-4">
                    <span className="text-sm font-semibold text-[#1B4D3E] tabular-nums">
                      {project.metric}
                    </span>
                    <span className="inline-flex items-center gap-1 text-sm font-medium text-[#16231C] group-hover:text-[#1B4D3E] whitespace-nowrap shrink-0">
                      <span>Ver detalhes</span>
                      <ArrowUpRight className="w-4 h-4" aria-hidden="true" />
                    </span>
                  </div>
                </div>
              </button>
            </motion.article>
          ))}
        </div>
      </div>

      {/* Lightbox / Project Detail Modal */}
      <AnimatePresence>
        {selectedProject && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={() => setSelectedProject(null)}
            className="fixed inset-0 z-50 bg-[#16231C]/70 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
            role="dialog"
            aria-modal="true"
            aria-labelledby="modal-project-title"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.97, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.97, y: 12 }}
              transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl border border-[#E3DDD1] max-w-3xl w-full overflow-hidden my-auto"
            >
              <div className="flex items-center justify-between gap-4 px-6 py-4 border-b border-[#E3DDD1]">
                <div className="text-xs text-[#4A5850] flex items-center gap-2">
                  <span className="font-medium text-[#1B4D3E]">
                    {selectedProject.category}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{selectedProject.location}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedProject(null)}
                  aria-label="Fechar detalhes do projeto"
                  className="w-10 h-10 rounded-lg border border-[#E3DDD1] flex items-center justify-center text-[#16231C] hover:bg-[#F7F4ED] transition-colors"
                >
                  <X className="w-5 h-5" aria-hidden="true" />
                </button>
              </div>

              <div className="max-h-[82vh] overflow-y-auto">
                <div className="aspect-[16/9] w-full bg-[#EFEAE0] border-b border-[#E3DDD1]">
                  <ResilientImage
                    src={selectedProject.image}
                    alt={`Apresentação do projeto ${selectedProject.title}`}
                    titleFallback={selectedProject.title}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="p-6 sm:p-8 space-y-6">
                  <div>
                    <h3
                      id="modal-project-title"
                      className="font-display text-2xl sm:text-3xl font-semibold text-[#16231C]"
                    >
                      {selectedProject.title}
                    </h3>
                    <p className="mt-2 text-base font-semibold text-[#1B4D3E] tabular-nums">
                      Resultado: {selectedProject.metric} · Prazo de entrega:{' '}
                      {selectedProject.turnaround}
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4 border-t border-[#E3DDD1]">
                    <div>
                      <h4 className="font-display text-sm font-semibold text-[#16231C]">
                        O desafio do cliente
                      </h4>
                      <p className="mt-1.5 text-sm leading-relaxed text-[#4A5850]">
                        {selectedProject.challenge}
                      </p>
                    </div>
                    <div>
                      <h4 className="font-display text-sm font-semibold text-[#16231C]">
                        Solução VELORA Studio
                      </h4>
                      <p className="mt-1.5 text-sm leading-relaxed text-[#4A5850]">
                        {selectedProject.solution}
                      </p>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-[#E3DDD1]">
                    <h4 className="font-display text-sm font-semibold text-[#16231C] mb-3">
                      O que foi entregue neste projeto
                    </h4>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {selectedProject.deliverables.map((item) => (
                        <li
                          key={item}
                          className="flex items-center gap-2 text-sm text-[#4A5850]"
                        >
                          <Check
                            className="w-4 h-4 text-[#1B4D3E] shrink-0"
                            aria-hidden="true"
                          />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="pt-4 border-t border-[#E3DDD1] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <span className="text-sm text-[#4A5850]">
                      Quer um resultado parecido para o seu segmento?
                    </span>
                    <a
                      href={buildWhatsAppUrl(
                        `Olá, VELORA Studio! Vi o projeto "${selectedProject.title}" no portfólio e quero solicitar um orçamento parecido.`
                      )}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center gap-2 px-5 py-3 min-h-[44px] rounded-xl bg-[#1B4D3E] hover:bg-[#143A2E] text-white text-sm font-medium transition-colors whitespace-nowrap"
                    >
                      <MessageCircle className="w-4 h-4" aria-hidden="true" />
                      <span>Solicitar orçamento pelo WhatsApp</span>
                    </a>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
