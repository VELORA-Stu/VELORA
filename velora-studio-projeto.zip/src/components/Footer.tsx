import { Instagram, MessageCircle } from 'lucide-react';
import {
  INSTAGRAM_HANDLE,
  INSTAGRAM_URL,
  WHATSAPP_DISPLAY,
  buildWhatsAppUrl,
} from '../data/veloraData';

const FOOTER_LINKS = [
  { href: '#inicio', label: 'Início' },
  { href: '#sobre', label: 'Sobre' },
  { href: '#servicos', label: 'Serviços' },
  { href: '#portfolio', label: 'Portfólio' },
  { href: '#depoimentos', label: 'Depoimentos' },
  { href: '#contato', label: 'Contato' },
];

export function Footer() {
  const whatsappHref = buildWhatsAppUrl();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-white border-t border-[#E3DDD1] py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 pb-8 border-b border-[#E3DDD1]">
          <div>
            <a
              href="#inicio"
              className="font-display text-xl font-bold tracking-tight text-[#16231C]"
            >
              VELORA Studio
            </a>
            <p className="mt-2 text-sm text-[#4A5850] max-w-md">
              Criação de sites profissionais, landing pages e presença digital
              estratégica. Atendimento online para todo o Brasil.
            </p>
          </div>

          <nav
            aria-label="Links do rodapé"
            className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-[#4A5850]"
          >
            {FOOTER_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="hover:text-[#1B4D3E] transition-colors whitespace-nowrap py-1"
              >
                {link.label}
              </a>
            ))}
          </nav>
        </div>

        <div className="pt-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs sm:text-sm text-[#4A5850]">
          <p>
            © {currentYear} VELORA Studio. Todos os direitos reservados.
          </p>

          <div className="flex flex-wrap items-center gap-5">
            <a
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-[#16231C] hover:text-[#1B4D3E] font-medium transition-colors tabular-nums"
            >
              <MessageCircle className="w-4 h-4 text-[#1B4D3E]" aria-hidden="true" />
              <span>{WHATSAPP_DISPLAY}</span>
            </a>

            <a
              href={INSTAGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-[#16231C] hover:text-[#1B4D3E] font-medium transition-colors"
            >
              <Instagram className="w-4 h-4 text-[#1B4D3E]" aria-hidden="true" />
              <span>{INSTAGRAM_HANDLE}</span>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
