import { useState } from 'react';
import { Monitor } from 'lucide-react';

interface ResilientImageProps {
  src: string;
  alt: string;
  titleFallback: string;
  className?: string;
  priority?: boolean;
}

export function ResilientImage({
  src,
  alt,
  titleFallback,
  className = '',
  priority = false,
}: ResilientImageProps) {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-[#F7F4ED] via-[#EFEAE0] to-[#E3EDE7] text-[#1B4D3E] p-6 text-center ${className}`}
      >
        <div className="w-12 h-12 rounded-xl bg-white/80 border border-[#D8D1C4] flex items-center justify-center mb-3">
          <Monitor className="w-6 h-6 text-[#1B4D3E]" aria-hidden="true" />
        </div>
        <span className="font-display text-sm font-semibold text-[#16231C]">
          {titleFallback}
        </span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      loading={priority ? 'eager' : 'lazy'}
      onError={() => setHasError(true)}
      className={className}
    />
  );
}
