import { MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { buildWhatsAppUrl } from '../data/veloraData';

export function FloatingWhatsApp() {
  const whatsappHref = buildWhatsAppUrl(
    'Olá, VELORA Studio! Gostaria de solicitar um orçamento pelo WhatsApp.'
  );

  return (
    <motion.a
      href={whatsappHref}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Solicitar orçamento pelo WhatsApp"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.25, delay: 0.35, ease: [0.16, 1, 0.3, 1] }}
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.97 }}
      className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-40 inline-flex items-center justify-center gap-2.5 h-13 w-13 sm:w-auto sm:px-5 rounded-full bg-[#1B4D3E] hover:bg-[#143A2E] text-white shadow-md border border-[#143A2E]/20 transition-colors duration-150"
    >
      <MessageCircle className="w-6 h-6 sm:w-5 sm:h-5 shrink-0" aria-hidden="true" />
      <span className="hidden sm:inline text-sm font-medium whitespace-nowrap">
        Orçamento no WhatsApp
      </span>
    </motion.a>
  );
}
